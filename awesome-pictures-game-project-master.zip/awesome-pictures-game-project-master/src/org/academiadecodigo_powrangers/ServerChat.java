package org.academiadecodigo_powrangers;

import org.academiadecodigo.bootcamp.Prompt;
import org.academiadecodigo.bootcamp.scanners.string.StringInputScanner;
import org.academiadecodigo_powrangers.tests.ClientPictureGame;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class ServerChat {

    private int port;
    private Set<String> userNames = new HashSet<>();
    private Set<UserThread> userThreads = new HashSet<>();
    BufferedReader filereader = null;
    Queue<String> filePaths = new LinkedList<>();
    String solution;


    // Collections to keep track the names and threads of the connected clients. Set is used because it doesn’t allow duplication and the order of elements does not matter
    public ServerChat(int port) {
        this.port = port;
    }

    public void execute() {

        try {
            ServerSocket serverSocket = new ServerSocket(port);

            System.out.println("Chat Server is listening on port " + port);

            filePaths.add("resources/chico.txt");
            filePaths.add("resources/fanuca.txt");
            filePaths.add("resources/chris.txt");
            filePaths.add("resources/ortins.txt");
            filePaths.add("resources/pedro.txt");
            filePaths.add("resources/telmo.txt");
            filePaths.add("resources/alana.txt");
            filePaths.add("resources/tomas.txt");
            // more images

            int counter = 0;
            int maxPlayers = 2;

            while (counter < maxPlayers) {
                Socket socket = serverSocket.accept();
                counter++;
                // put sockets in a thread, ask them their name.
                UserThread currentClient =  new UserThread(socket,this);
                userThreads.add(currentClient);
                System.out.println("Accapted someone!!! wooo, going to start their run");
                new Thread(currentClient).start();
            }

            // this needs to happen for EACH round....
            setup();


            /*
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New user login");


                UserThread userclient = new UserThread(socket, this);
                userThreads.add(userclient);
                userclient.start();
            }
*/

        } catch (IOException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        ServerChat server = new ServerChat(3657);
        server.execute();

    }



    public void setup() {

        try {
            String filepath = filePaths.poll();
            filereader = new BufferedReader(new FileReader(filepath));
            String[] answersplit = filepath.split("/");
            String[] answerspli2 = answersplit[1].split("\\.");
            solution = answerspli2[0];


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


    public void broadcast() {

        try {


            String[] lines = new String[15];
            String test = filereader.readLine();

            if(test == null){
                setup();
            }


            for (int i = 0; i < 15; i++) {
                String line = filereader.readLine();

                if (line != null) {
                    lines[i] = line + "\n";
                } else {
                    lines[i] = "";
                }
            }


            for (UserThread aUser : userThreads) {
                aUser.sendMessage(Arrays.toString(lines));

            }

            checkAnswer();

            // ISTO FOI SO UM TESTE, VAI DAR CACADA
            broadcast();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void addUserName(String userName) {
        userNames.add(userName);
    }

    // When a client is disconneted, removes the associated username and UserThread
    void removeUser(String userName, UserThread aUser) {
        boolean removed = userNames.remove(userName);
        if (removed) {
            userThreads.remove(aUser);
            System.out.println("The user " + userName + " quitted");
        }
    }

    Set<String> getUserNames() {
        return this.userNames;
    }

    // Returns true if there are other users connected (not count the currently connected user)
    boolean hasUsers() {
        return !this.userNames.isEmpty();
    }

    public void checkAnswer(){
        try {

            for (UserThread aUser : userThreads) {
                Socket socket =  aUser.getSocket();
                Prompt prompt = new Prompt(socket.getInputStream(), new PrintStream(socket.getOutputStream()));

                StringInputScanner askAnswer = new StringInputScanner();
                askAnswer.setMessage("What is your answer?");
                askAnswer.setError("C'mon, don´t be an ass!");

                String answer = prompt.getUserInput(askAnswer);

                String serverMessage = "New user connected, and his/her username is: " + aUser.userName;

                if(answer.equals(solution)){
                    aUser.getWriter().println("Nice one: " + aUser.userName);


                }else{
                    aUser.getWriter().println("Hmm not that person! Try again!!");
                    //broadcast();
                }


            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }






    }


}