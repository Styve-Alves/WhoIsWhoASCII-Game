package org.academiadecodigo_powrangers;

import java.io.*;
import java.net.Socket;

public class UserThread extends Thread {


    private Socket socket;
    private ServerChat server;
    String userName;


    private PrintWriter writer;

    public UserThread(Socket socket, ServerChat server) {
        this.socket = socket;
        this.server = server;
    }

    @Override
    public void run() {

        InputStream input = null;
        System.out.println(Thread.currentThread().getName());

        try {
            input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            OutputStream output = socket.getOutputStream();
            writer = new PrintWriter(output, true);
            printUsers();
            writer.println("Insert your username: ");
            System.out.println(Thread.currentThread().getName() + " about to write name");
            userName =  reader.readLine();
            System.out.println(Thread.currentThread().getName() + " wrote name");
            server.addUserName(userName);
            String serverMessage = "New user connected, and his/her username is: " + userName;


            System.out.println(Thread.currentThread().getName() + " before broadcast");
            server.broadcast();
            System.out.println(Thread.currentThread().getName() + " after broadcast");



            String clientMessage;
            do {

                System.out.println(Thread.currentThread().getName() + " iinsidde loop");
                sendMessage(userName + "waiting for your answer ;)");
                clientMessage = reader.readLine();
                sendMessage(userName + "your answer was " + clientMessage);


                serverMessage = "[" + userName + "]: " + clientMessage;
                server.broadcast();


            } while (!clientMessage.equals("bye"));

            server.removeUser(userName, this);
            socket.close();

            serverMessage = userName + " has quitted.";
            server.broadcast();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    // Sends a list of online users to the newly connected user.
    public void printUsers() {
        if (server.hasUsers()) {
            writer.println("Connected users: " + server.getUserNames());
        } else {
            writer.println("No other users connected");
        }
    }

    // Sends a message to the client.
    public void sendMessage(String message) {
        writer.println(message);
    }



    public PrintWriter getWriter() {
        return writer;
    }

    public Socket getSocket() {
        return socket;
    }
}
